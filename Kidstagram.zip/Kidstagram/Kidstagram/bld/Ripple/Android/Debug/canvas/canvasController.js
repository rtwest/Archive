﻿//canvasController


cordovaNG.controller('canvasController', function ($scope, globalService) {

    // Scope is like the partial view datamodel.  'message' is defined in the paritial view
    $scope.message = 'This is the Canvas view';

    // example function
    //$scope.functionName = function () {};


    var ctx, color = "#000";
    var line_Width = 5;


    // Function to setup a new canvas for drawing
    // ------------------------------------------
    $scope.newCanvas = function () {
        //define, resize, and insert canvas
        document.getElementById("content").style.height = window.innerHeight - 90;
        var canvas = '<canvas id="canvas" width="' + window.innerWidth + '" height="' + (window.innerHeight - 90) + '"></canvas>';
        document.getElementById("content").innerHTML = canvas;
        // setup canvas
        ctx = document.getElementById("canvas").getContext("2d");
        ctx.strokeStyle = color;
        // @@@@ Line Width
        ctx.lineWidth = line_Width;
        // setup to trigger drawing on mouse or touch
        drawTouch();
        drawMouse(); // only needed for testing
    };

    // For choosing the color
    // ------------------------------------------
    $scope.selectColor = function (clickEvent) {

        $scope.clickEvent = globalService.simpleKeys(clickEvent);

        // toggle the UI for the selected color
        for (var i = 0; i < document.getElementsByClassName("palette").length; i++) {
            document.getElementsByClassName("palette")[i].style.borderColor = "#777";
            document.getElementsByClassName("palette")[i].style.borderStyle = "solid";
        }
        clickEvent.target.style.borderColor = "#fff";
        clickEvent.target.style.borderStyle = "dashed";

        color = window.getComputedStyle(clickEvent.target).backgroundColor; // set color to palette
        ctx.beginPath(); // start a new line
        ctx.strokeStyle = color; // set the new line color
    };

    // prototype to	start drawing on TOUCH using canvas moveTo and lineTo
    // ------------------------------------------
    // @@@@   WHY THE -44PX ON Y AXIS?
    var drawTouch = function () {
        var start = function (e) {
            ctx.beginPath();
            x = e.changedTouches[0].pageX;
            y = e.changedTouches[0].pageY - 44;
            ctx.moveTo(x, y);
        };
        var move = function (e) {
            e.preventDefault();
            x = e.changedTouches[0].pageX;
            y = e.changedTouches[0].pageY - 44;
            ctx.lineTo(x, y);
            ctx.stroke();
        };
        document.getElementById("canvas").addEventListener("touchstart", start, false);
        document.getElementById("canvas").addEventListener("touchmove", move, false);
    };

    // prototype to	start drawing on MOUSE using canvas moveTo and lineTo
    // ------------------------------------------
    // @@@@   WHY THE -44PX ON Y AXIS?
    var drawMouse = function () {
        var clicked = 0;
        var start = function (e) {
            clicked = 1;
            ctx.beginPath();
            x = e.pageX;
            y = e.pageY - 44;
            ctx.moveTo(x, y);
        };
        var move = function (e) {
            if (clicked) {
                x = e.pageX;
                y = e.pageY - 44;
                ctx.lineTo(x, y);
                ctx.stroke();
            }
        };
        var stop = function (e) {
            clicked = 0;
        };
        document.getElementById("canvas").addEventListener("mousedown", start, false);
        document.getElementById("canvas").addEventListener("mousemove", move, false);
        document.addEventListener("mouseup", stop, false);
    };


    // Fuction to save the Canvas contents to an image on the file system
    // ------------------------------------------------------------------
    $scope.saveImage = function () {
        //window.canvas2ImagePlugin.saveImageDataToLibrary(
        //    function (msg) {
        //        console.log(msg);
        //    },
        //    function (err) {
        //        console.log(err);
        //    },
        //    document.getElementById('canvas')
        //);
        var imageData = canvas.toDataURL().replace(/data:image\/png;base64,/, '');
    };


});