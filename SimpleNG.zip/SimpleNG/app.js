﻿/* 
##################################################
##################################################

ISSUES
- When refreshing browser some of the {{bound}} data in the UI is empty.  Resolved with sesssionStorage and localStorage

##################################################
##################################################
*/ 



// ==================================================
// Create the module and name it azurepocApp
// - add the dependency for Azure Mobile Service Client
// - add the dependency for Angular UI Bootstrap to use Bootstrap for AngularJS
// ==================================================

var azurepocApp = angular.module('azurepocApp', [
    'ngRoute',
    'azure-mobile-service.module',
    'ui.bootstrap'
]);

// --------------------------------------------------


// ==================================================
// Configure the routes for navigation
// ==================================================

azurepocApp.config(function ($routeProvider) {
    $routeProvider
        // route for the home view
        .when('/', {
            templateUrl: 'partials/home.html',
            controller: 'mainController'
        })
        // route for the managed users view
        .when('/managedusers', {
            templateUrl: 'partials/managedusers.html',
            controller: 'managedusersController'
        })
        // route for the todo list view
        .when('/todolist', {
            templateUrl: 'partials/todolist.html',
            controller: 'todolistController'
        })
        // route for the about view
        .when('/about', {
            templateUrl: 'partials/about.html',
            controller: 'aboutController'
        })
        // route for the contact view
        .when('/contact', {
            templateUrl: 'partials/contact.html',
            controller: 'contactController'
        });
});
// --------------------------------------------------


// ==================================================
// Common Global Functions and Variables to reuse across controllers.  Service seems like a classes with methods and vars.
// Service can have dependencies with a werid 'injection notation' []
// Inject factory/service <name> as a dependency to controllers to make available.
// ==================================================

azurepocApp.service('globalService',['$location', function ($location) {

    // Global vars
    // ----------
    var managedUserGuid = ''; // Global var for the managed user ID to pass between controllers
    var userLoggedIn = ''; // For capturing the User Name from the Auth Provider properties

    // Global functions
    // ----------
    return {
        // Functions for get/set on global vars.  
        // !!!! Persistent Vars in the UI maybe better stored in SESSIONSTORAGE for reload on page refresh
        //----------
        getmanagedUserGuid : function () {
            return managedUserGuid;
        },
        setmanagedUserGuid : function (val){
            managedUserGuid = val;
        },
        getuserLoggedIn: function () {
            return userLoggedIn;
        },
        setuserLoggedIn: function (val) {
            userLoggedIn = val;
        },
        // Global functions
        // ----------------
        changeView: function (view) { // Simple method to change view anywhere
            $location.path(view); // path not hash
        },
        simpleKeys: function (original) { // Helper Recommedation from AngularJS site. Return a copy of an object with only non-object keys we need this to avoid circular references - though I'm not really sure why
        return Object.keys(original).reduce(function (obj, key) {
            obj[key] = typeof original[key] === 'object' ? '{ ... }' : original[key];
            return obj;
        }, {});}

    };

}]);


// ==================================================
// Create the controllers and inject Angular's $scope
// - Add Azureservice as a dependency to the controller to expose Azure DB methods
// - Add globalService as dependency to expose those methods and vars
// ==================================================

azurepocApp.controller('mainController', function ($scope, Azureservice, globalService) {

    // Scope is like the partial view datamodel.  'message' and 'loginstatus' are defined in the paritial view
    $scope.message = 'User login is ';
    $scope.loginstatus = Azureservice.isLoggedIn();

    // Had to wrap this Azure Mobile Client call into a function so it wasn't automatically called on view load for some reason
    $scope.azurelogin = function () {
        Azureservice.login('google')
        .then(function () {
            $scope.addAlert('alert successful');
            $scope.loginstatus = 'Login successful';
            

            // ###################################################
            // ---------------------------------------------------
            // Example of using a custom API on the Azure Mobile Service called 'servie-POC' that 
            // has 'user' preview function enabled using VS CLI
            Azureservice.invokeApi('userauthenticationproperties') // name of the Custom API
            .then(function (response) { // on success, return this JSON result
                if (response.google) { // if the response obj has a 'google' parameter, it's from Google 
                    // --------
                    // JSON digging specific to the Google Auth returned properties
                    globalService.setuserLoggedIn(response.google.name); // assign to global var in this service
                    console.log(globalService.getuserLoggedIn());
                    // ---------
                    // using html5 browser storage for just the session.  May have to convert from js obj to string, 
                    //    but not in the simple case below
                    sessionStorage.user = response.google.name;

                };
            },
            function (err) { console.error('Azure Custom API Error: ' + err); })
            // ###################################################

            // @@@@@@ using injected service 'global service' defined function to load another view
            globalService.changeView('managedusers'); 

        },
        function (err) {
            $scope.addAlert('alert' + err);
            $scope.loginstatus = 'Azure Error: ' + err;
        });
    };

    $scope.alerts = [];
    $scope.addAlert = function (status) {
        $scope.alerts.push({ msg: status });
    };
    $scope.closeAlert = function (index) {
        $scope.alerts.splice(index, 1);
    };

});



// ==================================================
// Create the controllers 
// ==================================================

azurepocApp.controller('managedusersController', function ($scope, Azureservice, globalService) {

    //$scope.message = globalService.getuserLoggedIn(); // name of user loggin from the Auth Provider stored in rootScope global var
    // Using html5 browser storage for just the session.  May have to convert from string to js obj, but not is this simple string case
    // Persistent Vars in the UI maybe better stored in SESSIONSTORAGE for reload on page refresh
    // --------------------------------------------------
    $scope.message = sessionStorage.user;

    // Creating var in the $scope view model and will bind to this in the HTML partial with 'ng-model=<$scope.var>'
    // ---------------------------------------------------
    $scope.managedUsernameToAdd = '';

    // Simple query for all rows from the table, 'mobileusertable'.  Like this, will fire on view load.
    // ---------------------------------------------------
    Azureservice.query('mobileusertable', {
        columns: ['id', 'mobileusername'] // Only return these columns
    })
    .then(function (mobileuserrows) { // Returned result var created here
        $scope.mobileuserrows = mobileuserrows;   // Assigin the results to a $scope variable 
    }, function (err) {console.error('There was an error quering Azure ' + err);});


    // Ng-repeat used to list DOM elements with DB table rowid loaded into elementID so its captured on the target.id
    // The Guid that was inserted into elementID on creation is capture and pass to the $rootScope global var.
    // ------------------------------------------
    $scope.manageduserclick = function (clickEvent) {
  
        $scope.clickEvent = globalService.simpleKeys(clickEvent);
        globalService.setmanagedUserGuid(clickEvent.target.id); // @@@ Get Managed User Guid from elementID and pass to Global Var in $rootScope
        console.log(globalService.getmanagedUserGuid());

        // Go to ToDo List view with the managed user Guid in the global var
        globalService.changeView('todolist'); // @@@ using globally defined function in $rootScope load another view

    };


    // Add from text box and insert new record into Azure
    // --------------------------------------------------
    $scope.addUser = function () {

        // Get value from text box
        // it's already bound to the $scope view model through ng-model=<$scope.var> in the HTML partial
        // ------------------------
        console.log($scope.managedUsernameToAdd);

        // Insert into Azure
        // ------------------------
        Azureservice.insert('mobileusertable', {
            mobileusername: $scope.managedUsernameToAdd // these is key/col_name : value
        })
        .then(function () {
            console.log('Insert successful');
            // After insert, re-query the DB to re-bind the repeater
            // ----------------
            Azureservice.query('mobileusertable', {
                columns: ['id', 'mobileusername'] // Only return these columns
            })
            .then(function (mobileuserrows) { // Returned result var created here
                $scope.mobileuserrows = mobileuserrows;   // Assigin the results to a $scope variable 
            }, function (err) { console.error('There was an error quering Azure ' + err); });

        }, function (err) { console.error('Azure Error: ' + err); })

    };

});


// ==================================================
// Create the controllers 
// ==================================================

azurepocApp.controller('todolistController', function ($scope, Azureservice, globalService) {
    
    //$scope.message = 'Welcome ' + globalService.getuserLoggedIn(); // name of user loggin from the Auth Provider stored in rootScope global var

    // Using html5 browser storage for just the session.  May have to convert from string to js obj, but not is this simple string case
    // Persistent Vars in the UI maybe better stored in SESSIONSTORAGE for reload on page refresh
    // --------------------------------------------------
    $scope.message = 'Welcome ' + sessionStorage.user;

    $scope.mobileusername = "<name goes here>";
    
    // Creating var in the $scope view model and will bind to this in the HTML partial with 'ng-model=<$scope.var>'
    // ---------------------------------------------------
    $scope.toDoItemTitle = '';



    // Query the Azure table
    // ---------------------------------------------------
    Azureservice.query('todotable', {
        criteria: {
            mobileid: globalService.getmanagedUserGuid() // Where statement - Guid put on global $rootScope var
        },
        columns: ['id', 'todoitemtitle', 'todoitemstatus'] // Only return these columns
    })
        .then(function (todolistforuser) {
            $scope.todolistforuser = todolistforuser;   // Assign the results to a $scope variable 
        }, function (err) {console.error('There was an error quering Azure ' + err);}
    );


    // Ng-repeat used to list DOM elements with DB table rowid loaded into elementID so its captured on the target.id
    // ------------------------------------------
    $scope.todoitemclick = function (clickEvent) {
  
        $scope.clickEvent = globalService.simpleKeys(clickEvent);
        $scope.toDoItemId = clickEvent.target.id;
        console.log('deleted item ' + $scope.toDoItemId + ' for user ' + globalService.getmanagedUserGuid());

        // Working here trying to test new secured delete script
        deleteTodoitem($scope.toDoItemId);

    };


    // Add from text box and insert new record into Azure
    // --------------------------------------------------
    $scope.addTodoitem = function () {

        // Get value from text box
        // it's already bound to the $scope view model through ng-model=<$scope.var> in the HTML partial
        // ------------------------
        console.log($scope.toDoItemTitle);

        // Insert into Azure
        // ------------------------
        Azureservice.insert('todotable', {
            todoitemtitle: $scope.toDoItemTitle, // these is key/col_name : value
            todoitemstatus: 'incomplete',
            mobileid: globalService.getmanagedUserGuid()
        })
        .then(function () {
            console.log('Insert successful');
            // Query the Azure table AGAIN
            // ---------------------------------------------------
            Azureservice.query('todotable', {
                criteria: {
                    mobileid: globalService.getmanagedUserGuid() // Where statement - Guid put on global $rootScope var
                },
                columns: ['id', 'todoitemtitle', 'todoitemstatus'] // Only return these columns
            })
                .then(function (todolistforuser) {
                    $scope.todolistforuser = todolistforuser;   // Assign the results to a $scope variable 
                }, function (err) { console.error('There was an error quering Azure ' + err); }
            );
        }, function (err) { console.error('Azure Error: ' + err); })
    };


    // Delete item from table in Azure
    // --------------------------------------------------
    function deleteTodoitem (tableRowId) {
        Azureservice.del('todotable', {
            id: tableRowId
        })
        .then(function () {
            console.log('Delete successful');
            // Query the Azure table (AGAIN)
            // ---------------------------------------------------
            Azureservice.query('todotable', {
                criteria: {
                    mobileid: globalService.getmanagedUserGuid() // Where statement - Guid put on global $rootScope var
                },
                columns: ['id', 'todoitemtitle', 'todoitemstatus'] // Only return these columns
            })
                .then(function (todolistforuser) {
                    $scope.todolistforuser = todolistforuser;   // Assign the results to a $scope variable 
                }, function (err) { console.error('There was an error quering Azure ' + err); }
            );
        }, function (err) { console.error('Azure Error: ' + err); })
    };


});


// ==================================================
// Create the controllers 
// ==================================================

azurepocApp.controller('aboutController', function ($scope) {
    $scope.message = 'Look! I am an about page.';
});

// ==================================================
// Create the controllers 
// ==================================================

azurepocApp.controller('contactController', function ($scope) {
    $scope.message = 'Contact us! JK. This is just a demo.';
});
// --------------------------------------------------

